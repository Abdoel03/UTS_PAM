package com.example.notesapp

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private lateinit var dbHelper: DBHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: UserAdapter
    private lateinit var userList: ArrayList<User>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DBHelper(this)
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        loadUsers()

        val fabAdd = findViewById<FloatingActionButton>(R.id.fabAdd)
        fabAdd.setOnClickListener { showAddDialog() }
    }

    private fun loadUsers() {
        userList = dbHelper.getAllUsers()
        adapter = UserAdapter(this, userList, dbHelper)
        recyclerView.adapter = adapter
    }

    fun showAddDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_add_user, null)
        val etNim = view.findViewById<EditText>(R.id.etNim)
        val etName = view.findViewById<EditText>(R.id.etName)
        val etEmail = view.findViewById<EditText>(R.id.etEmail)
        val etPhone = view.findViewById<EditText>(R.id.etPhone)

        AlertDialog.Builder(this)
            .setTitle("Tambah Data")
            .setView(view)
            .setPositiveButton("Simpan") { _, _ ->
                val nim = etNim.text.toString()
                val name = etName.text.toString()
                val email = etEmail.text.toString()
                val phone = etPhone.text.toString()
                if (dbHelper.insertUser(nim, name, email, phone)) {
                    loadUsers()
                    Toast.makeText(this, "Data tersimpan", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Gagal menyimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    fun showEditDialog(user: User) {
        val view = layoutInflater.inflate(R.layout.dialog_add_user, null)
        val etNim = view.findViewById<EditText>(R.id.etNim)
        val etName = view.findViewById<EditText>(R.id.etName)
        val etEmail = view.findViewById<EditText>(R.id.etEmail)
        val etPhone = view.findViewById<EditText>(R.id.etPhone)

        etNim.setText(user.nim)
        etName.setText(user.name)
        etEmail.setText(user.email)
        etPhone.setText(user.phone)

        AlertDialog.Builder(this)
            .setTitle("Edit Data")
            .setView(view)
            .setPositiveButton("Update") { _, _ ->
                val success = dbHelper.updateUser(
                    user.id,
                    etNim.text.toString(),
                    etName.text.toString(),
                    etEmail.text.toString(),
                    etPhone.text.toString()
                )
                if (success) {
                    loadUsers()
                    Toast.makeText(this, "Data diperbarui", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Gagal memperbarui", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
