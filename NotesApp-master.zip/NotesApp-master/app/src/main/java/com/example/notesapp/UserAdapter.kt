package com.example.notesapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView

class UserAdapter(
    private val context: Context,
    private var userList: ArrayList<User>,
    private val dbHelper: DBHelper
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvInfo: TextView = itemView.findViewById(R.id.tvInfo)
        val btnEdit: ImageButton = itemView.findViewById(R.id.btnEdit)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.user_item, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.tvInfo.text = "NIM: ${user.nim}\nNama: ${user.name}\nEmail: ${user.email}\nHP: ${user.phone}"

        holder.btnEdit.setOnClickListener {
            (context as MainActivity).showEditDialog(user)
        }

        holder.btnDelete.setOnClickListener {
            val success = dbHelper.deleteUser(user.id)
            if (success) {
                userList.removeAt(position)
                notifyItemRemoved(position)
                Toast.makeText(context, "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Gagal menghapus data", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun getItemCount(): Int = userList.size
}
