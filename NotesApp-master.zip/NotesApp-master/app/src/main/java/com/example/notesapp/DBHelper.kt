package com.example.notesapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UserDB"
        private const val DATABASE_VERSION = 2
        private const val TABLE_USERS = "users"

        private const val KEY_ID = "id"
        private const val KEY_NIM = "nim"
        private const val KEY_NAME = "name"
        private const val KEY_EMAIL = "email"
        private const val KEY_PHONE = "phone"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = ("CREATE TABLE $TABLE_USERS ("
                + "$KEY_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "$KEY_NIM TEXT,"
                + "$KEY_NAME TEXT,"
                + "$KEY_EMAIL TEXT,"
                + "$KEY_PHONE TEXT)")
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    fun insertUser(nim: String, name: String, email: String, phone: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(KEY_NIM, nim)
        values.put(KEY_NAME, name)
        values.put(KEY_EMAIL, email)
        values.put(KEY_PHONE, phone)
        val success = db.insert(TABLE_USERS, null, values)
        db.close()
        return success != -1L
    }

    fun getAllUsers(): ArrayList<User> {
        val userList = ArrayList<User>()
        val selectQuery = "SELECT * FROM $TABLE_USERS"
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery(selectQuery, null)

        if (cursor.moveToFirst()) {
            do {
                val user = User(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID)),
                    nim = cursor.getString(cursor.getColumnIndexOrThrow(KEY_NIM)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(KEY_NAME)),
                    email = cursor.getString(cursor.getColumnIndexOrThrow(KEY_EMAIL)),
                    phone = cursor.getString(cursor.getColumnIndexOrThrow(KEY_PHONE))
                )
                userList.add(user)
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return userList
    }

    fun updateUser(id: Int, nim: String, name: String, email: String, phone: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(KEY_NIM, nim)
        values.put(KEY_NAME, name)
        values.put(KEY_EMAIL, email)
        values.put(KEY_PHONE, phone)
        val success = db.update(TABLE_USERS, values, "$KEY_ID=?", arrayOf(id.toString()))
        db.close()
        return success > 0
    }

    fun deleteUser(id: Int): Boolean {
        val db = writableDatabase
        val success = db.delete(TABLE_USERS, "$KEY_ID=?", arrayOf(id.toString()))
        db.close()
        return success > 0
    }
}
