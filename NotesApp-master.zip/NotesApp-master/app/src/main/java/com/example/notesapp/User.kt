package com.example.notesapp

data class User(
    val id: Int,
    val nim: String,
    val name: String,
    val email: String,
    val phone: String
)
